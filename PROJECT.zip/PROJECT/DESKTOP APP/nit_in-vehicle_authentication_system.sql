-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2023 at 06:31 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nit in-vehicle authentication system`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_path`
--

CREATE TABLE `access_path` (
  `access_id` int(8) NOT NULL,
  `driver` varchar(30) NOT NULL,
  `license_number` varchar(100) NOT NULL,
  `time_in` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `time_out` datetime(6) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `access_path`
--

INSERT INTO `access_path` (`access_id`, `driver`, `license_number`, `time_in`, `time_out`, `status`) VALUES
(6, 'NIT/BIT/2020/1189', 'BP99 NPC\n', '2023-06-08 07:18:03.469195', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `consents`
--

CREATE TABLE `consents` (
  `consent_id` varchar(30) NOT NULL,
  `owner` varchar(30) NOT NULL,
  `picture` varchar(30) NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `RegNo` varchar(30) NOT NULL,
  `Fname` varchar(30) DEFAULT NULL,
  `Mname` varchar(30) DEFAULT NULL,
  `Lname` varchar(30) DEFAULT NULL,
  `Phone` int(15) DEFAULT NULL,
  `Email` varchar(1000) DEFAULT NULL,
  `Status` varchar(30) DEFAULT NULL,
  `Picture` varchar(30) DEFAULT NULL,
  `RegDate` datetime(6) DEFAULT NULL,
  `Password` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`RegNo`, `Fname`, `Mname`, `Lname`, `Phone`, `Email`, `Status`, `Picture`, `RegDate`, `Password`) VALUES
('NIT/BIT/2020/1189', 'CASTOR', 'G', 'NJOOLE', 711741690, 'castorgerald0610@gmail.com', 'Owner', 'NIT.BIT.2020.1189.jpg', '2023-06-08 07:17:08.000000', '13a8b8b6dd0de2117035fa9a1f67c55be79e0e11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access_path`
--
ALTER TABLE `access_path`
  ADD PRIMARY KEY (`access_id`),
  ADD KEY `driver` (`driver`);

--
-- Indexes for table `consents`
--
ALTER TABLE `consents`
  ADD KEY `owner` (`owner`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`RegNo`),
  ADD KEY `RegNo` (`RegNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access_path`
--
ALTER TABLE `access_path`
  MODIFY `access_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `access_path`
--
ALTER TABLE `access_path`
  ADD CONSTRAINT `access_path_ibfk_1` FOREIGN KEY (`driver`) REFERENCES `users` (`RegNo`) ON UPDATE CASCADE;

--
-- Constraints for table `consents`
--
ALTER TABLE `consents`
  ADD CONSTRAINT `consents_ibfk_1` FOREIGN KEY (`owner`) REFERENCES `users` (`RegNo`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
