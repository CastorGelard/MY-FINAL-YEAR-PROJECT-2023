import cv2
from My_Module import FaceRec
import mysql.connector
import pytesseract
import logging
import random
from datetime import datetime
import serial
import My_Module
import requests
from My_Module import FaceRec
from datetime import date
import secrets
import string
import time
from playsound import playsound

obj = FaceRec()
obj.load_encoding_images("images/")
cap = cv2.VideoCapture(1)
print("WAITING FOR A PASS...")
ser = serial.Serial('COM12', 9600)
while True:
    data = ser.read()
    decoded_data = data.decode()
    decoded_data = data.decode()
    if decoded_data == "1":
        #print("On Entry")
        #print("Waiting For Car Image On Entry")
        ret, frame = cap.read()
        PassFlag = True
        while PassFlag:
            cv2.imwrite("frame.jpg", frame)
            licenseNo = None
            api_key = "949e60799adfd3314fe80b9a13b8e0b990043902"
            image_path = "frame.jpg"
            licenseNo = My_Module.recognize_license_plate(image_path, api_key)
            # licenseNo = "T720ECE"
            if licenseNo is not None:
                #print(licenseNo)
                cv2.imshow("ENTRY DETAILS", frame)
                name = licenseNo + "_" + str(date.today()) + "_ENTRY"
                print("_____________________________________")
                print("DETECTED ON ENTRY " + licenseNo)
                pic_loc = "cars/" + name + ".jpg"
                cv2.imwrite(pic_loc, frame)
                # IDENTIFY DRIVER

                time.sleep(3)
                name = None
                while name is None:
                    # print("Waiting For a Face")
                    ret, frame = cap.read()
                    processed_frame = frame
                    face_locations, face_names = obj.detect_known_faces(processed_frame)
                    for face_loc, name in zip(face_locations, face_names):
                        y1, x2, y2, x1 = face_loc[0], face_loc[1], face_loc[2], face_loc[3]

                        cv2.putText(processed_frame, name, (x1, y1 - 10), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 0, 200),2)
                        cv2.rectangle(processed_frame, (x1, y1), (x2, y2), (0, 0, 200), 4)
                        cv2.imshow("ENTRY DETAILS", frame)
                        key = cv2.waitKey(1)

                        if name == "Unknown":
                            print("UNKNOWN USER")
                            print("NOT RECORDED")
                            print("_____________________________________")

                        else:
                            splited = name.split(".")
                            RegNo = splited[0] + "/" + splited[1] + "/" + splited[2] + "/" + splited[3]
                            # print(RegNo)
                            db = mysql.connector.connect(
                                host="localhost",
                                user="root",
                                password="",
                                database="nit in-vehicle authentication system"
                            )
                            cursor = db.cursor()
                            cursor.execute(
                                "SELECT MAX(access_id), time_out, license_number FROM `access_path` WHERE driver = %s",
                                (RegNo,))
                            rows = cursor.fetchall()
                            # print(rows[0])
                            if rows[0][0] is not None and rows[0][1] is None:
                                print("USER " + RegNo)
                                print("STATUS : INSIDE WITH " + rows[0][2])
                                print("_____________________________________")

                            else:
                                print("Recording...")
                                print(RegNo)
                                print(licenseNo)
                                query = "INSERT INTO access_path (driver, license_number) VALUES (%s, %s)"
                                values = (RegNo, licenseNo)
                                cursor.execute(query, values)
                                db.commit()
                                print(RegNo + " With " + licenseNo)
                                print("USER " + RegNo)
                                print("VEHICLE " + licenseNo)
                                print("RECORDED SUCCESSFULLY")
                                print("_____________________________________")
                                #ser = serial.Serial('COM12', 9600)
                                time.sleep(2)
                                data_to_send = '1'
                                ser.write(data_to_send.encode())
                                db = mysql.connector.connect(
                                    host="localhost",
                                    user="root",
                                    password="",
                                    database="nit in-vehicle authentication system"
                                )
                                cursor = db.cursor()
                                # licenseNo = "BP99 NPC"
                                query = "SELECT * FROM users WHERE RegNo = %s"
                                value = RegNo
                                cursor.execute(query, (value,))
                                rows = cursor.fetchone()
                                num_rows = cursor.rowcount
                                # print("Number of rows returned:", num_rows)
                                print(rows[4])

                                if num_rows == 1:
                                    if rows[4] is None:
                                        print("fail to get phone number")
                                    code = "255"
                                    api_key = '2b5a714d62b73706452f41f29253a124-384542cb-5f28-4007-acb7-37841f1acd57'
                                    base_url = 'https://ejzjr3.api.infobip.com'
                                    PhoneNumber = code + str(rows[4])
                                    # print(PhoneNumber)
                                    # PhoneNumber = '255689823207'
                                    message = 'Habari ' + rows[1] + ' ' + rows[2] + ' ' + rows[
                                        3] + ', Umeingia Chuoni na usafiri ' + licenseNo +'. Asante'
                                    url = f'{base_url}/sms/2/text/single'
                                    headers = {
                                        'Content-Type': 'application/json',
                                        'Authorization': f'App {api_key}'
                                    }
                                    payload = {
                                        'from': 'MY SYSTEM',
                                        'to': PhoneNumber,
                                        'text': message
                                    }
                                    response = requests.post(url, json=payload, headers=headers)
                                    if response.ok:
                                        print('SMS message sent successfully.')
                                    else:
                                        print(f'SMS message failed with status code: {response.status_code}')
                                        print(response.text)
                                #ser.close()

            else:
                print("LICENSE NUMBER NOT DETECTED")


            #key = cv2.waitKey()
            PassFlag = False
            #if key == 27:
                #break

    elif decoded_data == "0":
        #print("On Exit")
        PassFlag = True
        ret, frame = cap.read()
        while PassFlag:
            cv2.imwrite("frame.jpg", frame)
            licenseNo = None
            api_key = "949e60799adfd3314fe80b9a13b8e0b990043902"
            image_path = "frame.jpg"
            licenseNo = My_Module.recognize_license_plate(image_path, api_key)
            # licenseNo = "T720ECE"
            if licenseNo is not None:
                # print(licenseNo)
                cv2.imshow("ENTRY DETAILS", frame)
                name = licenseNo + "_" + str(date.today()) + "_ENTRY"
                print("_____________________________________")
                print("DETECTED ON EXIT " + licenseNo)

                # IDENTIFY DRIVER
                time.sleep(5)
                name = None
                while name is None:
                    # print("Waiting For a Face")
                    ret, frame = cap.read()
                    processed_frame = frame
                    face_locations, face_names = obj.detect_known_faces(processed_frame)
                    for face_loc, name in zip(face_locations, face_names):
                        y1, x2, y2, x1 = face_loc[0], face_loc[1], face_loc[2], face_loc[3]

                        cv2.putText(processed_frame, name, (x1, y1 - 10), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 0, 200),2)
                        cv2.rectangle(processed_frame, (x1, y1), (x2, y2), (0, 0, 200), 4)
                        cv2.imshow("EXIT DETAILS", processed_frame)
                        key = cv2.waitKey(1)

                        if name == "Unknown":
                            print("LICENSE " + licenseNo)
                            db = mysql.connector.connect(
                                host="localhost",
                                user="root",
                                password="",
                                database="nit in-vehicle authentication system"
                            )
                            cursor = db.cursor()
                            # licenseNo = "BP99 NPC"
                            query = "SELECT * FROM users WHERE RegNo IN (SELECT driver FROM access_path WHERE license_number = %s)"
                            value = licenseNo
                            cursor.execute(query, (value,))
                            rows = cursor.fetchone()
                            num_rows = cursor.rowcount
                            # print("Number of rows returned:", num_rows)

                            if num_rows == 1:
                                if rows[4] is None:
                                    print("fail to get phone number")
                                code = "255"
                                api_key = '2b5a714d62b73706452f41f29253a124-384542cb-5f28-4007-acb7-37841f1acd57'
                                base_url = 'https://ejzjr3.api.infobip.com'
                                PhoneNumber = code + str(rows[4])
                                # print(PhoneNumber)
                                #PhoneNumber = '255689823207'
                                message = 'Habari ' + rows[1] + ' ' + rows[2] + ' ' + rows[3] + ', Kuna sintofahamu ya gari lako. Tafadhari fika geti kubwa haraka sana. Asante'
                                url = f'{base_url}/sms/2/text/single'
                                headers = {
                                    'Content-Type': 'application/json',
                                    'Authorization': f'App {api_key}'
                                }
                                payload = {
                                    'from': 'MY SYSTEM',
                                    'to': PhoneNumber,
                                    'text': message
                                }
                                response = requests.post(url, json=payload, headers=headers)
                                if response.ok:
                                    print('SMS message sent successfully.')
                                else:
                                    print(f'SMS message failed with status code: {response.status_code}')
                                    print(response.text)

                                rand = random.randint(1, 1000)
                                name = licenseNo + "_" + str(date.today()) + str(rand)
                                pic_loc = "wezi/" + name + ".jpg"
                                print(name)
                                cv2.imwrite(pic_loc, frame)
                                alarm = "C:/Users/Tee/PycharmProjects/MY_PROJECTS/NJOOLE/alarm.wav"
                                playsound(alarm)
                            print("_____________________________________")

                        else:
                            splited = name.split(".")
                            RegNo = splited[0] + "/" + splited[1] + "/" + splited[2] + "/" + splited[3]
                            # print(RegNo)
                            db = mysql.connector.connect(
                                host="localhost",
                                user="root",
                                password="",
                                database="nit in-vehicle authentication system"
                            )
                            cursor = db.cursor()
                            query = "SELECT * FROM access_path WHERE access_id IS NOT NULL AND driver = %s AND time_out IS NULL"
                            value = RegNo

                            cursor.execute(query, (value,))
                            rows = cursor.fetchone()
                            num_rows = cursor.rowcount
                            # print("Number of rows returned:", num_rows)
                            if num_rows < 0:
                                print("MAY BE AN ERROR/CONSENT")
                                db = mysql.connector.connect(
                                    host="localhost",
                                    user="root",
                                    password="",
                                    database="nit in-vehicle authentication system"
                                )
                                cursor = db.cursor()
                                query = "SELECT * FROM consents WHERE consent_id = %s"
                                value = RegNo

                                cursor.execute(query, (value,))
                                rows = cursor.fetchone()
                                num_rows = cursor.rowcount
                                if num_rows == 1:
                                    Owner = rows[1]
                                    db = mysql.connector.connect(
                                        host="localhost",
                                        user="root",
                                        password="",
                                        database="nit in-vehicle authentication system"
                                    )
                                    cursor = db.cursor()
                                    query = "SELECT * FROM access_path WHERE access_id IS NOT NULL AND driver = %s AND time_out IS NULL"
                                    value = Owner
                                    cursor.execute(query, (value,))
                                    rows = cursor.fetchone()
                                    num_rows = cursor.rowcount
                                    if num_rows < 0:
                                        print("SIYO YEYE WALA SIO CONSENT")
                                        print("_____________________________________")

                                    elif num_rows == 1:
                                        if rows[4] is None:
                                            if licenseNo == rows[2]:
                                                print("NI CONSENT")
                                                print("LET'S OPEN THE GATE")
                                                print("_____________________________________")
                                                time.sleep(2)
                                                data_to_send = '1'
                                                ser.write(data_to_send.encode())
                                                try:
                                                    cnx = mysql.connector.connect(
                                                        host="localhost",
                                                        user="root",
                                                        password="",
                                                        database="nit in-vehicle authentication system"
                                                    )
                                                    cursor = cnx.cursor()
                                                    query = "UPDATE access_path SET time_out = %s, status = %s WHERE access_id = %s"
                                                    current_time = datetime.now()
                                                    values = (current_time, 'Consent', rows[0])
                                                    cursor.execute(query, values)
                                                    cnx.commit()
                                                    cursor.close()
                                                    cnx.close()

                                                except mysql.connector.Error as err:
                                                    print("Error while updating the database:", err)

                                                db = mysql.connector.connect(
                                                    host="localhost",
                                                    user="root",
                                                    password="",
                                                    database="nit in-vehicle authentication system"
                                                )
                                                cursor = db.cursor()
                                                # licenseNo = "BP99 NPC"
                                                query = "SELECT * FROM users WHERE RegNo = %s"
                                                value = Owner
                                                cursor.execute(query, (value,))
                                                rows = cursor.fetchone()
                                                num_rows = cursor.rowcount
                                                # print("Number of rows returned:", num_rows)
                                                print(rows[4])

                                                if num_rows == 1:
                                                    if rows[4] is None:
                                                        print("fail to get phone number")
                                                    code = "255"
                                                    api_key = '2b5a714d62b73706452f41f29253a124-384542cb-5f28-4007-acb7-37841f1acd57'
                                                    base_url = 'https://ejzjr3.api.infobip.com'
                                                    PhoneNumber = code + str(rows[4])
                                                    # print(PhoneNumber)
                                                    # PhoneNumber = '255689823207'
                                                    message = 'Habari ' + rows[1] + ' ' + rows[2] + ' ' + rows[
                                                        3] + ', Usafiri wako wa ' + licenseNo + ' umetoka na uliemhidhinisha. Asante'
                                                    url = f'{base_url}/sms/2/text/single'
                                                    headers = {
                                                        'Content-Type': 'application/json',
                                                        'Authorization': f'App {api_key}'
                                                    }
                                                    payload = {
                                                        'from': 'MY SYSTEM',
                                                        'to': PhoneNumber,
                                                        'text': message
                                                    }
                                                    response = requests.post(url, json=payload, headers=headers)
                                                    if response.ok:
                                                        print('SMS message sent successfully.')
                                                    else:
                                                        print(
                                                            f'SMS message failed with status code: {response.status_code}')
                                                        print(response.text)


                                            else:
                                                print("SIYO YEYE WALA SIO CONSENT")
                                                print("_____________________________________")

                                    elif num_rows == 0:
                                        print("SIYO YEYE WALA SIO CONSENT")
                                        print("_____________________________________")
                                    elif num_rows > 1:
                                        print("MARA YA MWISHO HAKUTOKA NALO (KWA CONSENT)")
                                        print("_____________________________________")
                                    else:
                                        print("MAY BE AN ERROR (KWA CONSENT)")
                                        print("_____________________________________")

                                else:
                                    print("NOT CONSENT, MAY BE A THIEF")
                                    db = mysql.connector.connect(
                                        host="localhost",
                                        user="root",
                                        password="",
                                        database="nit in-vehicle authentication system"
                                    )
                                    cursor = db.cursor()
                                    # licenseNo = "BP99 NPC"
                                    query = "SELECT * FROM users WHERE RegNo IN (SELECT driver FROM access_path WHERE license_number = %s)"
                                    value = licenseNo
                                    cursor.execute(query, (value,))
                                    rows = cursor.fetchone()
                                    num_rows = cursor.rowcount
                                    # print("Number of rows returned:", num_rows)

                                    if num_rows == 1:
                                        if rows[4] is None:
                                            print("fail to get phone number")
                                        code = "255"
                                        api_key = '2b5a714d62b73706452f41f29253a124-384542cb-5f28-4007-acb7-37841f1acd57'
                                        base_url = 'https://ejzjr3.api.infobip.com'
                                        PhoneNumber = code + str(rows[4])
                                        # print(PhoneNumber)
                                        # PhoneNumber = '255689823207'
                                        message = 'Habari ' + rows[1] + ' ' + rows[2] + ' ' + rows[
                                            3] + ', Kuna sintofahamu ya gari lako. Tafadhari fika geti kubwa haraka sana. Asante'
                                        url = f'{base_url}/sms/2/text/single'
                                        headers = {
                                            'Content-Type': 'application/json',
                                            'Authorization': f'App {api_key}'
                                        }
                                        payload = {
                                            'from': 'MY SYSTEM',
                                            'to': PhoneNumber,
                                            'text': message
                                        }
                                        response = requests.post(url, json=payload, headers=headers)
                                        if response.ok:
                                            print('SMS message sent successfully.')
                                        else:
                                            print(f'SMS message failed with status code: {response.status_code}')
                                            print(response.text)

                                        # splited = licenseNo.split(" ")
                                        # licenseNo = splited[0] + "" + splited[1]
                                        rand = random.randint(1, 1000)
                                        name = licenseNo + "_" + str(date.today()) + str(rand)
                                        pic_loc = "wezi/" + name + ".jpg"
                                        print(name)
                                        cv2.imwrite(pic_loc, frame)
                                        alarm = "C:/Users/Tee/PycharmProjects/MY_PROJECTS/NJOOLE/alarm.wav"
                                        playsound(alarm)

                                # print("_____________________________________")

                            elif num_rows == 0:
                                print("HAKUNA AMBALO HAKUTOKA NALO")
                                print("MAY BE A THIEF")
                                print("_____________________________________")
                                db = mysql.connector.connect(
                                    host="localhost",
                                    user="root",
                                    password="",
                                    database="nit in-vehicle authentication system"
                                )
                                cursor = db.cursor()
                                # licenseNo = "BP99 NPC"
                                query = "SELECT * FROM users WHERE RegNo IN (SELECT driver FROM access_path WHERE license_number = %s)"
                                value = licenseNo
                                cursor.execute(query, (value,))
                                rows = cursor.fetchone()
                                num_rows = cursor.rowcount
                                # print("Number of rows returned:", num_rows)

                                if num_rows == 1:
                                    if rows[4] is None:
                                        print("fail to get phone number")
                                    code = "255"
                                    api_key = '2b5a714d62b73706452f41f29253a124-384542cb-5f28-4007-acb7-37841f1acd57'
                                    base_url = 'https://ejzjr3.api.infobip.com'
                                    PhoneNumber = code + str(rows[4])
                                    # print(PhoneNumber)
                                    # PhoneNumber = '255689823207'
                                    message = 'Habari ' + rows[1] + ' ' + rows[2] + ' ' + rows[
                                        3] + ', Kuna sintofahamu ya gari lako. Tafadhari fika geti kubwa haraka sana. Asante'
                                    url = f'{base_url}/sms/2/text/single'
                                    headers = {
                                        'Content-Type': 'application/json',
                                        'Authorization': f'App {api_key}'
                                    }
                                    payload = {
                                        'from': 'MY SYSTEM',
                                        'to': PhoneNumber,
                                        'text': message
                                    }
                                    response = requests.post(url, json=payload, headers=headers)
                                    if response.ok:
                                        print('SMS message sent successfully.')
                                    else:
                                        print(f'SMS message failed with status code: {response.status_code}')
                                        print(response.text)

                                    # splited = licenseNo.split(" ")
                                    # licenseNo = splited[0] + "" + splited[1]
                                    rand = random.randint(1, 1000)
                                    name = licenseNo + "_" + str(date.today()) + str(rand)
                                    pic_loc = "wezi/" + name + ".jpg"
                                    print(name)
                                    cv2.imwrite(pic_loc, frame)
                                    alarm = "C:/Users/Tee/PycharmProjects/MY_PROJECTS/NJOOLE/alarm.wav"
                                    playsound(alarm)

                            elif num_rows == 1:
                                if rows[4] is None:
                                    if licenseNo == rows[2]:
                                        print("NI YEYE")
                                        print("LET'S OPEN THE GATE")
                                        print("_____________________________________")
                                        time.sleep(2)
                                        data_to_send = '1'
                                        ser.write(data_to_send.encode())
                                        try:
                                            cnx = mysql.connector.connect(
                                                host="localhost",
                                                user="root",
                                                password="",
                                                database="nit in-vehicle authentication system"
                                            )
                                            cursor = cnx.cursor()
                                            query = "UPDATE access_path SET time_out = %s, status = %s WHERE access_id = %s"
                                            current_time = datetime.now()
                                            values = (current_time, 'Owner', rows[0])
                                            cursor.execute(query, values)
                                            cnx.commit()
                                            cursor.close()
                                            cnx.close()

                                        except mysql.connector.Error as err:
                                            print("Error while updating the database:", err)

                                        db = mysql.connector.connect(
                                            host="localhost",
                                            user="root",
                                            password="",
                                            database="nit in-vehicle authentication system"
                                        )
                                        cursor = db.cursor()
                                        # licenseNo = "BP99 NPC"
                                        query = "SELECT * FROM users WHERE RegNo IN (SELECT driver FROM access_path WHERE license_number = %s)"
                                        value = licenseNo
                                        cursor.execute(query, (value,))
                                        rows = cursor.fetchone()
                                        num_rows = cursor.rowcount
                                        # print("Number of rows returned:", num_rows)

                                        if num_rows == 1:
                                            if rows[4] is None:
                                                print("fail to get phone number")
                                            code = "255"
                                            api_key = '2b5a714d62b73706452f41f29253a124-384542cb-5f28-4007-acb7-37841f1acd57'
                                            base_url = 'https://ejzjr3.api.infobip.com'
                                            PhoneNumber = code + str(rows[4])
                                            # print(PhoneNumber)
                                            # PhoneNumber = '255689823207'
                                            message = 'Habari ' + rows[1] + ' ' + rows[2] + ' ' + rows[
                                                3] + ', Umetoka chuoni na usafiri wako muda huu. Asante'
                                            url = f'{base_url}/sms/2/text/single'
                                            headers = {
                                                'Content-Type': 'application/json',
                                                'Authorization': f'App {api_key}'
                                            }
                                            payload = {
                                                'from': 'MY SYSTEM',
                                                'to': PhoneNumber,
                                                'text': message
                                            }
                                            response = requests.post(url, json=payload, headers=headers)
                                            if response.ok:
                                                print('SMS message sent successfully.')
                                            else:
                                                print(f'SMS message failed with status code: {response.status_code}')
                                                print(response.text)

                                        #"UPDATE access_path SET time_out = %s, status = %s WHERE access_id = %s"
                                        """current_time = datetime.now()
                                        values = (current_time, 'Owner', rows[0])
                                        cursor.execute(query, values)"""

                                    else:
                                        print("SIO LAKE")
                                        print("LAKE NI " + rows[2])
                                        db = mysql.connector.connect(
                                            host="localhost",
                                            user="root",
                                            password="",
                                            database="nit in-vehicle authentication system"
                                        )
                                        cursor = db.cursor()
                                        # licenseNo = "BP99 NPC"
                                        query = "SELECT * FROM users WHERE RegNo IN (SELECT driver FROM access_path WHERE license_number = %s)"
                                        value = licenseNo
                                        cursor.execute(query, (value,))
                                        rows = cursor.fetchone()
                                        num_rows = cursor.rowcount
                                        # print("Number of rows returned:", num_rows)

                                        if num_rows == 1:
                                            if rows[4] is None:
                                                print("fail to get phone number")
                                            code = "255"
                                            PhoneNumber = code + str(rows[4])
                                            api_key = '2b5a714d62b73706452f41f29253a124-384542cb-5f28-4007-acb7-37841f1acd57'
                                            base_url = 'https://ejzjr3.api.infobip.com'
                                            # print(PhoneNumber)
                                            # PhoneNumber = '255689823207'
                                            message = 'Habari ' + rows[1] + ' ' + rows[2] + ' ' + rows[
                                                3] + ', Kuna sintofahamu ya gari lako. Tafadhari fika geti kubwa haraka sana. Asante'
                                            url = f'{base_url}/sms/2/text/single'
                                            headers = {
                                                'Content-Type': 'application/json',
                                                'Authorization': f'App {api_key}'
                                            }
                                            payload = {
                                                'from': 'MY SYSTEM',
                                                'to': PhoneNumber,
                                                'text': message
                                            }
                                            response = requests.post(url, json=payload, headers=headers)
                                            if response.ok:
                                                print('SMS message sent successfully.')
                                            else:
                                                print(f'SMS message failed with status code: {response.status_code}')
                                                print(response.text)

                                            # splited = licenseNo.split(" ")
                                            # licenseNo = splited[0] + "" + splited[1]
                                            rand = random.randint(1, 1000)
                                            name = licenseNo + "_" + str(date.today()) + str(rand)
                                            pic_loc = "wezi/" + name + ".jpg"
                                            print(name)
                                            cv2.imwrite(pic_loc, frame)
                                            alarm = "C:/Users/Tee/PycharmProjects/MY_PROJECTS/NJOOLE/alarm.wav"
                                            playsound(alarm)
                                        print("_____________________________________")

                            elif num_rows > 1:
                                print("MARA YA MWISHO HAKUTOKA NALO")
                                print("_____________________________________")

                            else:
                                print("MAY BE AN ERROR")
                                print("_____________________________________")

            else:
                print("LICENSE NUMBER NOT DETECTED")

            #cv2.imshow("RECOGNITION", frame)
            # key = cv2.waitKey()
            PassFlag = False
            # if key == 27:
            # break

    else:
        print("SERIAL COMMUNICATION ERROR (Entry/Exit)")
    cv2.imshow("RECOGNITION", frame)
    key = cv2.waitKey(1)
    if key == 27:
        break
ser.close()
cap.release()
cv2.destroyAllWindows()