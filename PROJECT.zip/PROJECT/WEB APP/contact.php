<?php

//if (session_status() !== PHP_SESSION_ACTIVE) {session_start();}
if(session_id() == '' || !isset($_SESSION)){session_start();}

?>

<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contact Us || NJOOLE Online MiniShop</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>

    <?php include_once("includes/header_new.php"); ?>
    <div class="row" style="margin-top:30px;">
      <div class="small-12">

        <p>Welcome:</p> 
 
    <p>Chat us on <a href="https://wa.me/+255711741690">WhatsApp</a></p>
    
    <p>Email us at <a href="mailto:infotrial88@gmail.com">infotrial88@gmail.com</a></p>

        <?php include_once("includes/footer_new.php"); ?>
      </div>
    </div>







    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
