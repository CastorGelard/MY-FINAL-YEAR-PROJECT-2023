<?php
session_start();
if(isset($_SESSION['RegNo']))
{
	$Error = "HINT: Upload clear picture...";
  if ($_SERVER['REQUEST_METHOD'] == "POST")
{
  $Uname = $_SESSION['RegNo'];
 $img_name = $_FILES['img']['name'];
 include_once ("includes/functions.php");
  $filedetails = $_FILES['img'];
  //print_r ($filedetails)."<br>";
  $Name = $_FILES['img'] ['name'];
  $Type = $_FILES['img'] ['type'];
  $Size = $_FILES['img'] ['size'];
  $Err = $_FILES['img'] ['error'];
  $Tmp = $_FILES['img'] ['tmp_name'];
  $xxxx = explode(".",$Name);
  //$Ext1 = $xxxx[1];
  $Ext2 = strtolower(end($xxxx));
  $allowedFiles = array('jpeg','jpg','png');
if (in_array($Ext2, $allowedFiles))
{
  if ($Err === 0)
      {
        if ($Size <= 5000000)
        {
        $cn= explode("/",$Uname);
        //echo $Uname;
        //print_r($cn);
        $cn[0]="CONSENT";
        $fcn = $cn[0]."/".$cn[1]."/".$cn[2]."/".$cn[3];
        $pidcf = $cn[0].".".$cn[1].".".$cn[2].".".$cn[3].".".$Ext2;
        $pidcfgg = $cn[0].".".$cn[1].".".$cn[2].".".$cn[3].".".$Ext2;
        $newName = uniqid().".".$Ext2;
        //$newDP = "Consent_".uniqid().".".$Ext2;

          $destination = 'C:/Users/Tee/PycharmProjects/MY_PROJECTS/NJOOLE/images/'.$pidcf;
          move_uploaded_file($Tmp, $destination);
          //print $destination;
          $qry = "INSERT INTO consents (consent_id,owner,picture) VALUES ('$fcn','$Uname','$pidcfgg');";
          include ("config.php");
          $result1 = mysqli_query($mysqli,$qry);
          mysqli_close($mysqli);
          if ($result1 == "True")
          {
            $Error = "Added Successfully";
          }
        }
        else
        {
        //echo "No";
          $Error ="File is too large.";
        }
        
      }
      else
      {
       $Error ="-An error occured-";
      }
}
else
{
$Error ="-File format not allowed-"; 
 




}
	
}

?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit Profile|| NIT In-Vehicle Authentication System</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>
  <?php
  include_once ("includes/header_new.php");
  include_once ("includes/functions.php");
  //echo "<h5>".greetings()." ".ucfirst($_SESSION['Username'])."</h5>";
  ?>
  
    <center>
    <br>
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" enctype="multipart/form-data" style="margin-top:30px; margin-top:30px; width: 65%; backgrouncd-color: gray;">
<script>
if ( window.history.replaceState )
{
window.history.replaceState( null, null, window.location.href );
}
</script>
              <h3 style="text-align:left;">CONSENT</h3>
              <!--<input type="text" id="right-label" placeholder="Username..." name="man_name"  >-->
              <input type="file" id="right-label" name="img"  >

              <span class ="error" style="text-align: left;"><?php echo $Error; ?></span>
              <input type="submit" value="SUBMIT" name = "login" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px; width: 100%;">

</form>
</center><br><br><br>


    <div class="row" style="margin-top:10px;">
      <div class="small-12">

        <footer>
           <p style="text-align:center; font-size:0.8em;">&copy; NIT In-Vehicle Authentication System. All Rights Reserved.</p>
        </footer>

      </div>
    </div>




    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
<?php   
}
else
{
header('Location: login.php');
die(); 
}
?>