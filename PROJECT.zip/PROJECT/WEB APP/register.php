<?php
if(session_id() == '' || !isset($_SESSION))
{
  session_start();
  include_once("includes/functions.php");
  $Error="Welcome";
  if ($_SERVER['REQUEST_METHOD'] == "POST")
    {
       $Pass1 = SHA1(strtoupper(test_input($_POST["pass1"])));
       $Pass2 = SHA1(strtoupper(test_input($_POST["pass2"])));
       if ($Pass1 == $Pass2)
       {
        $phone = test_input($_POST["phone"]);
        if (strlen($phone) <= 10) 
        {
          $Pass = $Pass1;
       $RegNumber = strtoupper(test_input($_POST["RegNumber"]));
       $qry1 = "SELECT RegNo FROM users WHERE RegNo = '$RegNumber';";
       include("config.php");
       $result1 = mysqli_query($mysqli,$qry1);
       mysqli_close($mysqli);
       if (mysqli_num_rows($result1) == 0)
       {
          $status = "Owner";
          $fname = strtoupper(test_input($_POST["fname"]));
          $mname = strtoupper(test_input($_POST["mname"]));
          $lname = strtoupper(test_input($_POST["lname"]));
          $Name = $_FILES['img'] ['name'];
          $Type = $_FILES['img'] ['type'];
          $Size = $_FILES['img'] ['size'];
          $Err = $_FILES['img'] ['error'];
          $Tmp = $_FILES['img'] ['tmp_name'];
          $Ext_Array = explode(".",$Name);
          $array = explode("/", $RegNumber);
          $PicName = $array[0].".".$array[1].".".$array[2].".".$array[3];
          $NameToSave = $PicName.".".strtolower($Ext_Array[1]);
          //echo $Ext_Array[1];
          $allowedFiles = array('jpeg','jpg','png');
          if (in_array(strtolower($Ext_Array[1]), $allowedFiles))
          {
            $targetDirectory = "C:/Users/Tee/PycharmProjects/MY_PROJECTS/NJOOLE/images/"; // Specify the directory where you want to store the uploaded files
            $targetFile = $targetDirectory . $NameToSave; // Get the path of the uploaded file
            //echo $targetFile;
              if (move_uploaded_file($_FILES["img"]["tmp_name"], $targetFile))
              {
                  $qry2 = "INSERT INTO users (RegNo,Fname,Mname,Lname,Phone,Status,Picture,RegDate,Password) VALUES ('$RegNumber','$fname','$mname','$lname','$phone','$status','$NameToSave',NOW(),'$Pass');";
                    //echo $qry2."<br>";
                 include("config.php");
                 //echo $qry2;
                 $result2 = mysqli_query($mysqli,$qry2);
                 mysqli_close($mysqli);
                 //print_r($result2);
                 //echo $qry3;
                 if ($result2 == "True")
                 {
                    $pythonScript = 'C:\Users\Tee\PycharmProjects\MY_PROJECTS\NJOOLE\run_in_php.py';
                    //Execute the Python script
                    //$output = shell_exec("python " . $pythonScript);
                    $Error = "Registered Successifully";
                 }
                 else
                 {
                  $Error ="*Failed To Register*";
                 }

                  //echo "File uploaded successfully.";
              }
              else
              {
                  $Error = "*Error uploading file.*";
              }

          }
          else
          {
            $Error = "File not Allowed";
          }
       }
       else
       {
        $Error="*REGISTRATION NUMBER EXISTS*";
       }
        }
        else
        {
          $Error = "Phone number exeeds limit";
        }
      
       }
       else
       {
        $Error = "Password Mismatch";
       }

    
    }//ENDS REQUEST_METHOD

}


?>

<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register || NIT In-Vehicle Authentication System</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <link rel="stylesheet" href="css/new.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>

    <?php
    include_once ("includes/header_new.php");
    ?>




    <center>
      <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" enctype="multipart/form-data" style="margin-top:30px; width: 73%; backgrouncd-color: gray;">
      <script>
        if ( window.history.replaceState )
        {
          window.history.replaceState( null, null, window.location.href );
        }
      </script>
          <div>
              <h3 style="text-align:left;">REGISTER</h3>
              <input type="text" id="right-label" placeholder="Reg Number..." name="RegNumber" required>
              <input type="text" id="right-label" placeholder="Fist Name..." name="fname" required>
              <input type="text" id="right-label" placeholder="Mid Name..." name="mname" required>
              <input type="text" id="right-label" placeholder="Last Name..." name="lname" required>
              <input type="number" id="right-label" placeholder="Phone (No country code)..." maxlength = "10" name="phone" required>
              <input type="file" id="right-label" placeholder="Picture..." name="img" required>
              <input type="password" id="password" name="pass1" placeholder="Password">
              <input type="password" id="password" name="pass2" placeholder="Confirm password">
<p id="password-validation"></p>

<script>
  var passwordInput = document.getElementById("password");
  var passwordValidation = document.getElementById("password-validation");

  passwordInput.addEventListener("input", function() {
    var password = passwordInput.value;
    var validationMessage = "";

    // Check if the password meets your desired criteria
    if (password.length < 8) {
      validationMessage = "Password must be at least 8 characters long.";
    } else if (!/[A-Z]/.test(password)) {
      validationMessage = "Password must contain at least one uppercase letter.";
    } else if (!/[a-z]/.test(password)) {
      validationMessage = "Password must contain at least one lowercase letter.";
    } else if (!/[0-9]/.test(password)) {
      validationMessage = "Password must contain at least one digit.";
    } else if (!/[!@#$%^&*]/.test(password)) {
      validationMessage = "Password must contain at least one special character.";
    }

    // Display the validation message
    passwordValidation.textContent = validationMessage;
  });
</script>

              
              <span class ="error" style="text-align: left;"><?php echo $Error; ?></span>
              <!--<p>By clicking "SUBMIT", You agree with our <a href="Terms.php">Terms.</a></p>-->
              <input type="submit" ijd="right-label" value="SUBMIT" name = "post" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px; width: 100%;">
              <!--<input type="reset" id="right-label" value="Reset" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px;">-->
            </div>
    </form>
  </center>

    <div class="row" style="margin-top:10px;">
      <div class="small-12">

        <?php include_once("includes/footer_new.php") ?>

      </div>
    </div>




    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
