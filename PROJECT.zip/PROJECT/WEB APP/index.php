<?php

//if (session_status() !== PHP_SESSION_ACTIVE) {session_start();}
if(session_id() == '' || !isset($_SESSION))
{
session_start();
$Error = "Login";
if (isset($_POST['login']))
{
include_once 'includes/functions.php';
$username = test_input($_POST["username"]);
$password = SHA1(test_input($_POST["pwd"]));
$qry = "SELECT * FROM users WHERE RegNo = '$username' AND Password = '$password';";
include ('config.php');
$result = mysqli_query($mysqli,$qry);
mysqli_close($mysqli);
if(mysqli_num_rows($result)==1)
{
  $_SESSION = mysqli_fetch_assoc($result);
  if ($_SESSION["Status"] == "Admin")
  {
    header("location:Admin.php");
  }
  else
  {
    header("location:User.php");
  }

}
elseif(mysqli_num_rows($result)==0)
{
  $Error = 'Incorrect Login...';
  //header("Refresh: 3; url=login.php");
}
else
{
 echo "User found not equal to expected, ".mysqli_num_rows($result)." Users";
}
}
/*
else
{
  echo "Form not submited";
}
*/
  }

if(isset($_SESSION["username"])){

        header("location:index.php");
}

?>

<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login || NIT In-Vehicle Authentication System</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>

    <?php
    include_once ("includes/header_new.php");
    ?>




    
            <center>
            <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" style="margin-top:30px; margin-top:30px; width: 65%; backgrouncd-color: gray;">
              <script>
              if ( window.history.replaceState )
              {
              window.history.replaceState( null, null, window.location.href );
              }
              </script>
              <h3 style="text-align:left;"><?php echo $Error; ?></h3>
              <input type="text" id="right-label" placeholder="Reg Number..." name="username" required >
              <input type="password" id="right-label" placeholder="Password..." name="pwd" required>
              <span class ="error" style="text-align: left;">Welcome</span>
               Haven't an account? <a href="register.php" style="color:blue;">REGISTER</a> 
              <p><a href="forgot_pass.php" style="color:blue">Forgot Password?</a></p>
              <input type="submit" value="Login" name = "login" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px; width: 48%; float: left;">

              <input type="reset" id="right-label" value="Reset" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px; width: 48%; float:right;">

</form>
</center><br><br><br>


    <div class="row" style="margin-top:10px;">
      <div class="small-12">

        <footer>
           <p style="text-align:center; font-size:0.8em;">&copy; NIT In-Vehicle Authentication System. All Rights Reserved.</p>
        </footer>

      </div>
    </div>




    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
