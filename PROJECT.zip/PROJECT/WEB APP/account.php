<?php

//if (session_status() !== PHP_SESSION_ACTIVE) {session_start();} for php 5.4 and above

if(session_id() == '' || !isset($_SESSION)){session_start();}

if(!isset($_SESSION["Username"]))
{
  header("location:login.php");
}
else
{
//BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  
  if($_SESSION["status"]==="Business man")
  {
    include_once("includes/header_new.php");
    ?>
    <!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Account || NJOOLE Online MiniShop</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>
    <div class="row" style="margin-top:30px;">
      <div class="small-12">
        &nbsp &nbsp <p><?php echo ' <h3> Hi ' .ucfirst($_SESSION['Username']).'</h3>'; ?></p>
        &nbsp &nbsp<img src="<?php echo 'images/dp/'.$_SESSION['dp']; ?>" alt = "NO DP" style = "width: 20%; height: 120px; bordeJr-radius: 50%;">

        <h4>Account Details</h4>
        Below are your details in the database. If you wish to change anything, then just enter new data in text box and click on update.
      </div>
    </div>


    <form method="POST" action="update.php" style="margin-top:30px;">
      <div class="row">
        <div class="small-12">

          <div class="row">
            <div class="small-3 columns">
              <label for="right-label" class="right inline">FNAME</label>
            </div>
            <div class="small-8 columns end">
              <?php
                include 'config.php';
                $result = $mysqli->query('SELECT * FROM users_new WHERE user_ID = '.$_SESSION["user_ID"]);
                mysqli_close($mysqli);
                if($result === FALSE)
                {
                  die(mysql_error());
                }

                if($result) {
                  $obj = $result->fetch_object();
                  echo '<input type="text" id="right-label" placeholder="'. $obj->Fname. '" name="fname">';

                  echo '</div>';
                    echo '</div>';

                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">MNAME</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';

                  echo '<input type="text" id="right-label" placeholder="'. $obj->Mname. '" name="lname">';

                  echo '</div>';
                  echo '</div>';
                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">LNAME</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';

                  echo '<input type="text" id="right-label" placeholder="'. $obj->Lname. '" name="lname">';

                  echo '</div>';
                  echo '</div>';

                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">UNAME</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  echo '<input type="text" id="right-label" placeholder="'. $obj->Username. '" name="uname">';
                  echo '</div>';
                  echo '</div>';

                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">PHONE</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  $phn = "0".$obj->Phone;
                  echo '<input type="text" id="right-label" placeholder="'.$phn. '" name="phone">';
                  echo '</div>';
                  echo '</div>';

                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">BRAND</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  echo '<input type="text" id="right-label" placeholder="'. $obj->Brand. '" name="brand" readonly>';
                  echo '</div>';
                  echo '</div>';

                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">EMAIL</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  echo '<input type="email" id="right-label" placeholder="'. $obj->Email. '" name="email" readonly>';
                  echo '</div>';
                  echo '</div>';

                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">DATE</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  echo '<input type="text" id="right-label" placeholder="'. $obj->Date. '" name="date" readonly>';
                  echo '</div>';
                  echo '</div>';

                  }

          ?>

          <div class="row">
            <div class="small-4 columns">

            </div>
            <div class="small-8 columns">
              <input type="submit" id="right-label" value="Update" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px;">
              <input type="reset" id="right-label" value="Reset" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px;">
            </div>
          </div>
        </div>
      </div>
    </form>



    <div class="row" style="margin-top:30px;">
      <div class="small-12">

        <?php include_once("includes/footer_new.php"); ?>

      </div>
    </div>







    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
<?php
   }
  
   //CUSTOMER CUSTOM CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER CUSTOMER 
  elseif ($_SESSION["status"]==="Customer")
  {
    include_once("includes/header_new.php");
    ?>
    <!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Account || NJOOLE Online MiniShop</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>
    <div class="row" style="margin-top:30px;">
      <div class="small-12">
        &nbsp &nbsp <p><?php echo ' <h3> Hi ' .ucfirst($_SESSION['Username']).'</h3>'; ?></p>
        &nbsp &nbsp<img src="<?php echo 'images/dp/'.$_SESSION['dp']; ?>" alt = "NO DP" style = "width: 20%; height: 120px; bordeJr-radius: 50%;">
        <p><h4>Account Details</h4></p>

        <p>Below are your details in the database. If you wish to change anything, then just enter new data in text box and click on update.</p>
      </div>
    </div>


    <form method="POST" action="update.php" style="margin-top:30px;">
      <div class="row">
        <div class="small-12">

          <div class="row">
            <div class="small-3 columns">
              <label for="right-label" class="right inline">UNAME</label>
            </div>
            <div class="small-8 columns end">
              <?php
                include 'config.php';
                $result = $mysqli->query('SELECT * FROM users_new WHERE user_ID = '.$_SESSION["user_ID"]);
                mysqli_close($mysqli);
                if($result === FALSE)
                {
                  die(mysql_error());
                }

                if($result) 
                {
                  $obj = $result->fetch_object();
                  echo '<input type="text" id="right-label" placeholder="'. $obj->Username. '" name="fname">';

                  echo '</div>';
                    echo '</div>';

                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">PHONE</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  $phn = "0".$obj->Phone;
                  echo '<input type="text" id="right-label" placeholder="'.$phn. '" name="lname">';
                  echo '</div>';
                  echo '</div>';

                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">EMAIL</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  echo '<input type="email" id="right-label" placeholder="'. $obj->Email. '" name="email" readonly>';
                  echo '</div>';
                  echo '</div>';


                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">DATE</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  echo '<input type="text" id="right-label" placeholder="'. $obj->Date. '" name="lname" readonly>';
                  echo '</div>';
                  echo '</div>';


              }
          ?>

          <div class="row">
            <div class="small-4 columns">

            </div>
            <div class="small-8 columns">
              <input type="submit" id="right-label" value="Update" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px;">
              <input type="reset" id="right-label" value="Reset" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px;">
            </div>
          </div>
        </div>
      </div>
    </form>



    <div class="row" style="margin-top:30px;">
      <div class="small-12">

        <?php include_once("includes/footer_new.php"); ?>

      </div>
    </div>







    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
    <?php
  }//MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  
  elseif ($_SESSION["status"]==="Manager")
  {
    include_once("includes/header_new.php");
    ?>
    <!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Account || NJOOLE Online MiniShop</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>
    <div class="row" style="margin-top:30px;">
      <div class="small-12">
        &nbsp &nbsp <p><?php echo ' <h3> Hi ' .ucfirst($_SESSION['Username']).'</h3>'; ?></p>
        &nbsp &nbsp<img src="<?php echo 'images/dp/'.$_SESSION['dp']; ?>" alt = "NO DP" style = "width: 20%; height: 120px; bordeJr-radius: 50%;">
        <p><h4>Account Details</h4></p>

        <p>Below are your details in the database. If you wish to change anything, then just enter new data in text box and click on update.</p>
      </div>
    </div>


    <form method="POST" action="update.php" style="margin-top:30px;">
      <div class="row">
        <div class="small-12">

          <div class="row">
            <div class="small-3 columns">
              <label for="right-label" class="right inline">UNAME</label>
            </div>
            <div class="small-8 columns end">
              <?php
                include 'config.php';
                $result = $mysqli->query('SELECT * FROM users_new WHERE user_ID = '.$_SESSION["user_ID"]);
                mysqli_close($mysqli);
                if($result === FALSE)
                {
                  die(mysql_error());
                }

                if($result) 
                {
                  $obj = $result->fetch_object();
                  echo '<input type="text" id="right-label" placeholder="'. $obj->Username. '" name="fname">';

                  echo '</div>';
                    echo '</div>';

                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">PHONE</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  $phn = "0".$obj->Phone;
                  echo '<input type="text" id="right-label" placeholder="'.$phn. '" name="lname">';
                  echo '</div>';
                  echo '</div>';

                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">EMAIL</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  echo '<input type="email" id="right-label" placeholder="'. $obj->Email. '" name="email" readonly>';
                  echo '</div>';
                  echo '</div>';


                  echo '<div class="row">';
                  echo '<div class="small-3 columns">';
                  echo '<label for="right-label" class="right inline">DATE</label>';
                  echo '</div>';
                  echo '<div class="small-8 columns end">';
                  echo '<input type="text" id="right-label" placeholder="'. $obj->Date. '" name="lname" readonly>';
                  echo '</div>';
                  echo '</div>';


              }
          ?>

          <div class="row">
            <div class="small-4 columns">

            </div>
            <div class="small-8 columns">
              <input type="submit" id="right-label" value="Update" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px;">
              <input type="reset" id="right-label" value="Reset" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px;">
            </div>
          </div>
        </div>
      </div>
    </form>



    <div class="row" style="margin-top:30px;">
      <div class="small-12">

        <?php include_once("includes/footer_new.php"); ?>

      </div>
    </div>







    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
    <?php
  }
  else
  {
    echo "We cant identify you";
  }
}
?>