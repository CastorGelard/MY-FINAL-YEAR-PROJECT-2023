<?php
session_start();
if(isset($_SESSION['Username']))
{
	$Error = "HINT: Username should be short...";
  if ($_SERVER['REQUEST_METHOD'] == "POST")
{
 $img_name = $_FILES['img']['name'];
 
 
 if(strlen($_POST['man_name'])<=15)
 {
 $txt = ($_POST['man_name']);
 $uname = $_SESSION["Phone"];
 $pass = $_SESSION["Password"];
 //$txt = test_input($_POST['man_name']);
 /*
 echo $img_name."<br>";
 echo $txt."<br>";
 echo $uname."<br>";
 echo $pass."<br>";
 */
//BOTH EMPTY BEGIN
if(empty($img_name) && empty($txt))
 {
   $Error = "Must fill at least one field! <a href='customer.php' style='color:blue;'> -HOME-<br></a>"; 
 }
//BOTH EMPTY END
//ONLY TEXT BEGIN
 elseif(empty($img_name) && !empty($txt))
 {
   include_once ("includes/functions.php");
   $txt = ucfirst(strtolower(test_input($_POST['man_name'])));
   $qry = "UPDATE users_new SET Username = '$txt' WHERE Phone = '$uname' AND Password = '$pass';";
   include ("config.php");
   $result = mysqli_query($mysqli,$qry);
   mysqli_close($mysqli);
   if ($result == "True")
   {  
   $qry1 = "SELECT * FROM users_new WHERE Phone = '$uname' AND Password = '$pass';";
     include ("config.php");
     $result1 = mysqli_query($mysqli,$qry1);
     mysqli_close($mysqli);
     if (mysqli_num_rows ($result1) == 1)
     {     
       $_SESSION = mysqli_fetch_assoc($result1);
       if($_SESSION["status"] == "Manager")
       {
       Header ("location:manager.php"); 
       }
       elseif($_SESSION["status"] == "Customer")
       {
       Header ("location:customer.php"); 
       }
       elseif($_SESSION["status"] == "admin")
       {
       Header ("location:admin.php");  
       }
       elseif($_SESSION["status"] == "Business man")
       {
       Header ("location:business_patner.php");  
       }
       
     }
    else
     {
       $Error = "No";
     }   
   }
   else
   {
    $Error = "Edit failed";
   }   
 }//ONLY TEXT END
 
//ONLY IMG BEGIN 
 elseif(!empty($img_name) && empty($txt))
 {
  include_once ("includes/functions.php");
  $txt = ucfirst(strtolower(test_input($_POST['man_name'])));
  $filedetails = $_FILES['img'];
  //print_r ($filedetails)."<br>";
  $Name = $_FILES['img'] ['name'];
  $Type = $_FILES['img'] ['type'];
  $Size = $_FILES['img'] ['size'];
  $Err = $_FILES['img'] ['error'];
  $Tmp = $_FILES['img'] ['tmp_name'];
  $xxxx = explode(".",$Name);
  //$Ext1 = $xxxx[1];
  $Ext2 = strtolower(end($xxxx));
//$Phone=$_SESSION['Phone'];
//$Password=$_SESSION['Password'];
/*
  echo $Name."<br>"."<br>";
  echo $Type."<br>"."<br>";
  echo $Size."<br>"."<br>";
  echo $Err."<br>"."<br>";
  echo $Tmp."<br>"."<br>";
  echo $uname."<br>";
 echo $pass."<br>";
  
//  print_r ($Ext2);
//  print_r ($Ext1);
*/
$allowedFiles = array('jpeg','jpg','png');
if (in_array($Ext2, $allowedFiles))
{
  if ($Err === 0)
      {
        if ($Size <= 5000000)
        {
        $newName = uniqid().".".$Ext2;
          $newDP = "Dp_".$_SESSION['Username']."_".uniqid().".".$Ext2;
          $destination = 'images/dp/'.$newDP;
          move_uploaded_file($Tmp, $destination);
          $qry = "UPDATE users_new SET dp = '$newDP' WHERE Phone = '$uname' AND Password = '$pass';";
          include ("config.php");
          $result1 = mysqli_query($mysqli,$qry);
          mysqli_close($mysqli);
     
//  echo $qry;
  /*        
  echo $Name."<br>"."<br>";
  echo $Type."<br>"."<br>";
  echo $Size."<br>"."<br>";
  echo $Err."<br>"."<br>";
  echo $Tmp."<br>"."<br>";
  echo $destination."<br>"."<br>";
//  print_r ($Ext2);
    */                
        if ($result1 == "True")
   {
  // echo "Yes";
   $qry2 = "SELECT * FROM users_new WHERE Phone = '$uname' AND Password = '$pass';";
     include ("config.php");
     $result2 = mysqli_query($mysqli,$qry2); 
     mysqli_close($mysqli);
   if (mysqli_num_rows ($result2) == 1)
     {     
       $_SESSION = mysqli_fetch_assoc($result2);
       if($_SESSION["status"] == "Manager")
       {
       Header ("location:manager.php"); 
       }
       elseif($_SESSION["status"] == "Customer")
       {
       Header ("location:customer.php"); 
       }
       elseif($_SESSION["status"] == "Business man")
       {
       Header ("location:business_patner.php");  
       }
       elseif($_SESSION["status"] == "admin")
       {
       Header ("location:admin.php");  
       }
     }
    else
     {
       $Error = "No";
     }   
   }        
        }
        else
        {
        //echo "No";
          $Error ="-This image is too large-";
        }
        
      }
      else
      {
       $Error ="-An error occured-";
      }
}
else
{
$Error ="-File format not allowed-";
} 
 }//ONLY IMG END
 //BOTH NOT EMPTY BEGIN
elseif(!empty($img_name) && !empty($txt))
 {
  include_once ("includes/functions.php");
  $filedetails = $_FILES['img'];
  //print_r ($filedetails)."<br>";
  $Name = $_FILES['img'] ['name'];
  $Type = $_FILES['img'] ['type'];
  $Size = $_FILES['img'] ['size'];
  $Err = $_FILES['img'] ['error'];
  $Tmp = $_FILES['img'] ['tmp_name'];
  $xxxx = explode(".",$Name);
  //$Ext1 = $xxxx[1];
  $Ext2 = strtolower(end($xxxx));
//$Phone=$_SESSION['Phone'];
//$Password=$_SESSION['Password'];
/*
  echo $Name."<br>"."<br>";
  echo $Type."<br>"."<br>";
  echo $Size."<br>"."<br>";
  echo $Err."<br>"."<br>";
  echo $Tmp."<br>"."<br>";
  echo $uname."<br>";
 echo $pass."<br>";
  
//  print_r ($Ext2);
//  print_r ($Ext1);
*/
$allowedFiles = array('jpeg','jpg','png');
if (in_array($Ext2, $allowedFiles))
{
  if ($Err === 0)
      {
        if ($Size <= 5000000)
        {
        $newName = uniqid().".".$Ext2;
        $newDP = "Dp_".$_SESSION['Username']."_".uniqid().".".$Ext2;
          $destination = 'images/dp/'.$newDP;
          move_uploaded_file($Tmp, $destination);
          $qry = "UPDATE users_new SET dp = '$newDP' ,Username ='$txt' WHERE Phone = '$uname' AND Password = '$pass';";
          include ("config.php");
          $result1 = mysqli_query($mysqli,$qry);
          mysqli_close($mysqli);
  
//  echo $qry;
  /*        
  echo $Name."<br>"."<br>";
  echo $Type."<br>"."<br>";
  echo $Size."<br>"."<br>";
  echo $Err."<br>"."<br>";
  echo $Tmp."<br>"."<br>";
  echo $destination."<br>"."<br>";
//  print_r ($Ext2);
    */                
        if ($result1 == "True")
   {
  // echo "Yes";
     $qry2 = "SELECT * FROM users_new WHERE Phone = '$uname' AND Password = '$pass';";
     include ("config.php");
     $result2 = mysqli_query($mysqli,$qry2);
     mysqli_close($mysqli);  
   if (mysqli_num_rows ($result2) == 1)
     {     
       $_SESSION = mysqli_fetch_assoc($result2);
       if($_SESSION["status"] == "Manager")
       {
       Header ("location:manager.php"); 
       }
       elseif($_SESSION["status"] == "Customer")
       {
       Header ("location:customer.php"); 
       }
      elseif($_SESSION["status"] == "Business man")
       {
       Header ("location:business_patner.php");  
       }
       elseif($_SESSION["status"] == "admin")
       {
       Header ("location:admin.php");  
       }
     }
    else
     {
       $Error = "No";
     }   
   }        
        }
        else
        {
        //echo "No";
          $Error ="File is too large.";
        }
        
      }
      else
      {
       $Error ="-An error occured-";
      }
}
else
{
$Error ="-File format not allowed-"; 
}
} 
 else
 {
   $Error = "We don't understand whether a txt or img is empty!"; 
 }
 
 
 
 ;
 }
 else
 {
  $Error = "Name maximum 15 characters <a href='customer.php' style='color:blue;'>-HOME-</a>";
 }
 
 



}
	


?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit Profile|| NJOOLE Online MiniShop</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>
  <?php
  include_once ("includes/header_new.php");
  include_once ("includes/functions.php");
  //echo "<h5>".greetings()." ".ucfirst($_SESSION['Username'])."</h5>";
  ?>
  
    <center>
    <br>
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" enctype="multipart/form-data" style="margin-top:30px; margin-top:30px; width: 65%; backgrouncd-color: gray;">
<script>
if ( window.history.replaceState )
{
window.history.replaceState( null, null, window.location.href );
}
</script>
              <h3 style="text-align:left;">EDIT PROFILE</h3>
              <input type="text" id="right-label" placeholder="Username..." name="man_name"  >
              <input type="file" id="right-label" name="img"  >

              <span class ="error" style="text-align: left;"><?php echo $Error; ?></span>
              <input type="submit" value="SUBMIT" name = "login" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px; width: 100%;">

</form>
</center><br><br><br>


    <div class="row" style="margin-top:10px;">
      <div class="small-12">

        <footer>
           <p style="text-align:center; font-size:0.8em;">&copy; NJOOLE Online MiniShop. All Rights Reserved.</p>
        </footer>

      </div>
    </div>




    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
<?php   
}
else
{
header('Location: login.php');
die(); 
}
?>