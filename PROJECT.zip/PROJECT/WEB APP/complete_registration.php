<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register || NJOOLE Online MiniShop</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <link rel="stylesheet" href="css/new.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>

    <?php
    $Error = "Welcome";
    include_once ("includes/header_new.php");
    ?>




    <center>
      <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" style="margin-top:30px; width: 73%; backgrouncd-color: gray;">
      <script>
        if ( window.history.replaceState )
        {
          window.history.replaceState( null, null, window.location.href );
        }
      </script>
          <div>
              <u><h3 style="text-align:left;">COMPLETE REGISTRATION</h3></u>
             <h3 style="text-align:left;">Brand</h3>       
              <input type="text" id="right-label" placeholder="Brand Name..." name="fname" required>
              <h3 style="text-align:left;">Logo</h3>
              <input type="file" id="right-label" placeholder="" name="mname" required>
              
              
              <span class ="error" style="text-align: left;"><?php echo $Error; ?></span>
              
              <input type="submit" ijd="right-label" value="SUBMIT" name = "post" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px; width: 100%;">
              <!--<input type="reset" id="right-label" value="Reset" style="background: #0078A0; border: none; color: #fff; font-family: 'Helvetica Neue', sans-serif; font-size: 1em; padding: 10px;">-->
            </div>
    </form>
  </center>

    <div class="row" style="margin-top:10px;">
      <div class="small-12">

        <?php include_once("includes/footer_new.php") ?>

      </div>
    </div>




    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
