<footer>
    <p style="text-align:center; font-size:0.8em;">&copy; NIT In-Vehicle Authentication System. All Rights Reserved.</p>
</footer>