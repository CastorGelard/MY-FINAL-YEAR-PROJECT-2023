<?php
date_default_timezone_set("Africa/Dar_es_Salaam");
//TEST INPUT
function test_input($data)
{
    $data = trim($data);
    $data = htmlspecialchars($data);
    $data = stripslashes($data);
    return $data;
}

//GREETINGS
function greetings()
{
if (date("H") >= 00 && date("H") < 12)
{
 $great = "Good Morning";
}
elseif (date("H") >= 12 && date("H") < 15)
{
 $great = "Good Afternoon";
}
elseif (date("H") >= 15 && date("H") < 19)
{
 $great = "Good Evening";
}
else
{
$great = "Good Night";
}
return $great;
}

//DATE
function today()
{
 $day = date ("l - d/m/Y");
 return $day;
}

//TIME
function now()
{
 $now = date ("H:i -A");
 return $now;
}

//echo greetings();


?>