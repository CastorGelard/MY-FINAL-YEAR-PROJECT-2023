<nav class="top-bar" data-topbar role="navigation">
      <ul class="title-area">
        <li class="name">
          <?php
          if(isset($_SESSION['Username']))
          {
            //CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  CUSTOMER  
            if($_SESSION['status'] === "Customer")
            {
              echo '<h1><a href="customer.php" style = "margin-left:-12px ;">HOME || NJOOLE Online MiniShop</a></h1>';
              ?>
              </li>
              <li class="toggle-topbar menu-icon"><a href="#"><span></span></a></li>
              </ul>

              <section class="top-bar-section">
              <!-- Right Nav Section -->
              <ul class="right">
              <li><a href="products.php">Products</a></li>
              <li><a href="contact.php">Contact Us</a></li>
              <li><a href="about.php">About Us</a></li>
              <?php

              if(isset($_SESSION['Username']))
              {
                 echo '<li><a href="cart.php">View Cart</a></li>';
                 //echo '<li class="active"><a href="account.php">My Account</a></li>';
                 echo '<li><a href="logout.php">Log Out</a></li>';
              }
            else
              {
               echo '<li><a href="login.php">Log In</a></li>';
               echo '<li><a href="register.php">Register</a></li>';
              }
              ?>
                </ul>
                </section>
                </nav>
              <?php
            }
            //BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  BUSINESS MAN  
            elseif($_SESSION['status'] === "Business man")
            {
              echo '<h1><a href="business_patner.php" style = "margin-left:-12px ;">HOME || NJOOLE Online MiniShop</a></h1>';
              ?>
              </li>
              <li class="toggle-topbar menu-icon"><a href="#"><span></span></a></li>
              </ul>

              <section class="top-bar-section">
              <!-- Right Nav Section -->
              <ul class="right">
              <li><a href="products.php">Products</a></li>
              <li><a href="contact.php">Contact Us</a></li>
              <li><a href="about.php">About Us</a></li>
              <?php

              if(isset($_SESSION['Username']))
              {
                 echo '<li><a href="logout.php">Log Out</a></li>';
              }
            else
              {
               echo '<li><a href="login.php">Log In</a></li>';
               echo '<li><a href="register.php">Register</a></li>';
              }
              ?>
                </ul>
                </section>
                </nav>
              <?php
            }
            //ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN ADMIN
            elseif($_SESSION['status'] === "Admin")
            {
              echo '<h1><a href="admin.php" style = "margin-left:-12px ;">HOME || NJOOLE Online MiniShop</a></h1>';
              ?>
              </li>
              <li class="toggle-topbar menu-icon"><a href="#"><span></span></a></li>
              </ul>

              <section class="top-bar-section">
              <!-- Right Nav Section -->
              <ul class="right">
              <li><a href="products.php">Products</a></li>
              <li><a href="contact.php">Contact Us</a></li>
              <li><a href="about.php">About Us</a></li>
              <?php

              if(isset($_SESSION['Username']))
              {
                 echo '<li class="active"><a href="account.php">My Account</a></li>';
                 echo '<li><a href="logout.php">Log Out</a></li>';
              }
            else
              {
               echo '<li><a href="login.php">Log In</a></li>';
               echo '<li><a href="register.php">Register</a></li>';
              }
              ?>
                </ul>
                </section>
                </nav>
              <?php
            }
            //MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  MANAGER  
            elseif($_SESSION['status'] === "Manager")
            {
              echo '<h1><a href="maniger.php" style = "margin-left:-12px ;">HOME || NJOOLE Online MiniShop</a></h1>';
              ?>
              </li>
              <li class="toggle-topbar menu-icon"><a href="#"><span></span></a></li>
              </ul>

              <section class="top-bar-section">
              <!-- Right Nav Section -->
              <ul class="right">
              <li><a href="products.php">Products</a></li>
              <li><a href="contact.php">Contact Us</a></li>
              <li><a href="about.php">About Us</a></li>
              <?php

              if(isset($_SESSION['Username']))
              {
                 echo '<li class="active"><a href="account.php">My Account</a></li>';
                 echo '<li><a href="logout.php">Log Out</a></li>';
              }
            else
              {
               echo '<li><a href="login.php">Log In</a></li>';
               echo '<li><a href="register.php">Register</a></li>';
              }
              ?>
                </ul>
                </section>
                </nav>
              <?php







            }
            
          }
          else
          {
            //echo '<h1><a href="index.php" style = "margin-left:-12px ;">HOME || NJOOLE Online MiniShop</a></h1>';
            echo "<a href = 'index.php' ><img src = 'images/new.png' style = 'height:40px; margin-top:3px;'/></a>";
            ?>
            </li>
              <li class="toggle-topbar menu-icon"><a href="#"><span></span></a></li>
              </ul>

              <section class="top-bar-section">
              <!-- Right Nav Section -->
              <ul class="right">
             <li><a href="contact.php">Contact Us</a></li>
              <li><a href="about.php">About Us</a></li>
              <?php

              if(isset($_SESSION['Username']))
              {
                 
                 echo '<li><a href="cart.php">View Cart</a></li>';
                 echo '<li><a href="order_history.php">My Orders</a></li>';
                 echo '<li class="active"><a href="account.php">My Account</a></li>';
                 echo '<li><a href="logout.php">Log Out</a></li>';
              }
            else
              {
               echo '<li><a href="login.php">Log In</a></li>';
               echo '<li><a href="register.php">Register</a></li>';
              }
              ?>
                </ul>
                </section>
                </nav>
            <?php
          }
          ?>